<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <h1>Edit Task</h1>
                                <!-- begin page title -->
                                    <form action="updatetask" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Project Name</label>
                                                <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($pj->project_id == $ac->project_id): ?>
                                                        <input type="text" class="form-control" placeholder="Enter Project Name" disabled name="pname" value="<?php echo e($pj->project); ?>">
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div> 

                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Task Name</label>
                                                <input type="text" class="form-control"  placeholder="Enter Task Name" name="task" value="<?php echo e($ac->work); ?>" autofocus>
                                            </div>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($u->user_id == $ac->user_id): ?>
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Team Name</label>
                                                            <input type="text" class="form-control" placeholder="Enter Team Name" disabled name="tname" value="<?php echo e($u->team_name); ?>">
                                                        </div> 

                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">User Name</label>
                                                            <input type="text" class="form-control" placeholder="Enter User Name" disabled name="uname" value="<?php echo e($u->name); ?>">
                                                        </div> 
                                                    <?php endif; ?>
                                                    <?php if($u->user_id == $ac->update_id): ?>
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Last Update By User</label>
                                                            <input type="text" class="form-control" placeholder="Enter User Name" disabled name="update" value="<?php echo e($u->name); ?>">
                                                        </div> 
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </form>
                            </div>
                        </div>
                        <!-- end row -->
                       
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
            </div>
            <!-- end app-container -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/edit-task.blade.php ENDPATH**/ ?>