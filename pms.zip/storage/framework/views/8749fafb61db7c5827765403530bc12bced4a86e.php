<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>PMS</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="index"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">community</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        
                        <div class="row">
                            
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mail-chat py-5 px-5">
                                            <div class="media align-items-center">
                                                <div class="bg-img mr-3">
                                                    <img src="assets/img/profile/<?php echo e($row1->profile); ?>" class="img-fluid" alt="user">
                                                </div>
                                                <div>
                                                    <h4 class="mb-0"><?php echo e($row1->name); ?></h4>
                                                    <p><?php echo e($row->time); ?></p>
                                                </div>
                                            </div>
                                            <div class="mt-4 d-flex justify-content-between">
                                                <div>
                                                    <h3><?php echo e($row->problem_name); ?></h3>
                                                </div>
                                            </div>
                                            <div>
                                                <p class="mb-2"><?php echo e($row->problem); ?></p>
                                            </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><hr />
                        <h2>Solution : </h2>
                        <?php $__currentLoopData = $solution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="mail-chat py-5 px-5">
                                            <div class="media align-items-center">
                                                <div class="bg-img mr-3">
                                                    <img src="assets/img/profile/<?php echo e($row1->profile); ?>" class="img-fluid" alt="user">
                                                </div>
                                                <div>
                                                    <h5 class="mb-0"><?php echo e($row1->name); ?></h5>
                                                    <p><?php echo e($row->time); ?></p>
                                                </div>
                                                
                                            </div>
                                            <div class="mt-4 d-flex justify-content-between">
                                                <div>
                                                    <h4>Solution : <?php echo e($row->solution); ?></h4>
                                                </div>
                                            </div>
                                            <div>
                                                <h6 class="mb-2">Message : <?php echo e($row->message); ?></h6>
                                            </div>
                                    </div>
                                </div>
                                <hr/>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-xl-12">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Give Solution</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <form action="addsolution" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Solution</label>
                                                <textarea type="text" name="solution" class="form-control"  placeholder="Enter Solution"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Message</label>
                                                <textarea type="text" name="message" class="form-control"  placeholder="Enter Message"></textarea>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
            </div>
            <!-- end app-container -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/problem-show.blade.php ENDPATH**/ ?>