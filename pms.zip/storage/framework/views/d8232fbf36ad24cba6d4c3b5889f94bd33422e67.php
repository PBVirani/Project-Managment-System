<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>Apex Chart</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="index.html"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                    Charts
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">Apex
                                                    Chart</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Line Chart with Data Labels</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo1"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Gradient Line Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo2"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Spline Area Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Stacked Area Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo4"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Bar Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo5"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Bar with Negative Values</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo6"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Donut Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo7"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card card-statistics">
                                    <div class="card-header">
                                        <div class="card-heading">
                                            <h4 class="card-title">Pie Chart</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="apexchart-wrapper">
                                            <div id="apexdemo8"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
            </div>
            <!-- end app-container -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/edittask.blade.php ENDPATH**/ ?>