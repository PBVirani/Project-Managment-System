<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
                <!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                       
                        <!-- begin row -->
                        
                        <div class="row">
                            <a href="addproject" class="mb-5 btn btn-block btn-info py-3 ">Add Project</a>
                            <div class="col-xxl-12 mb-30">
                                <div class="card card-statistics h-100 mb-0">
                                    <div class="card-header d-flex justify-content-between">
                                        <div class="card-heading">
                                            <h4 class="card-title">Ongoing projects</h4>
                                        </div>
                                       
                                    </div>
                                    <div class="card-body">
                                        <div class="scrollbar scroll_dark">
                                            <div class="table-responsive">
                                                <table id="datatable-buttons" class="table mb-0 table-borderless">
                                                    <thead class="bg-light">
                                                        <tr>
                                                            <th>Project Name </th>
                                                            <th> Start Date </th>
                                                            <th> Due Date </th>
                                                            <th>Team </th>
                                                            <th>Status</th>
                                                            <th>Project Details</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody >
                                                        
                                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($row->status == 0): ?>
                                                        <tr>
                                                                <td> <a href="project-details/<?php echo e($row->project_id); ?>"><?php echo e($row->project); ?></a></td>
                                                                <td><?php echo e($row->start_date); ?></td>
                                                                <td><?php echo e($row->due_date); ?></td>
                                                                <td><?php echo e($row->team_id); ?></td>
                                                                <?php if($row->status == 0): ?>
                                                                    <td><label class="badge badge-info-inverse">In Progress</label></td>
                                                                <?php else: ?>
                                                                    <td><label class="badge badge-info-inverse">Complete</label></td>
                                                                <?php endif; ?>
                                                                <td><?php echo e($row->details); ?></td>
                                                        </tr>
                                                        <?php endif; ?>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                            
                            <div class="col-xxl-12 mb-30">
                                <div class="card card-statistics h-100 mb-0">
                                    <div class="card-header d-flex justify-content-between">
                                        <div class="card-heading">
                                            <h4 class="card-title">Complete projects</h4>
                                        </div>
                                       
                                    </div>
                                    <div class="card-body">
                                        <div class="scrollbar scroll_dark">
                                            <div class="table-responsive">
                                                <table id="datatable-buttons" class="table mb-0 table-borderless">
                                                    <thead class="bg-light">
                                                        <tr>
                                                            <th>Project Name </th>
                                                            <th> Start Date </th>
                                                            <th> Due Date </th>
                                                            <th>Team </th>
                                                            <th>Status</th>
                                                            <th>Project Details</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody >
                                                        
                                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($row->status == 1): ?>
                                                        <tr>
                                                                <td> <a href="project-details/<?php echo e($row->project_id); ?>"><?php echo e($row->project); ?></a></td>
                                                                <td><?php echo e($row->start_date); ?></td>
                                                                <td><?php echo e($row->due_date); ?></td>
                                                                <td><?php echo e($row->team_id); ?></td>
                                                                <?php if($row->status == 0): ?>
                                                                    <td><label class="badge badge-info-inverse">In Progress</label></td>
                                                                <?php else: ?>
                                                                    <td><label class="badge badge-info-inverse">Complete</label></td>
                                                                <?php endif; ?>
                                                                <td><?php echo e($row->details); ?></td>
                                                        </tr>
                                                        <?php endif; ?>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
            </div>
            <!-- end app-container -->
           
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/monitering.blade.php ENDPATH**/ ?>