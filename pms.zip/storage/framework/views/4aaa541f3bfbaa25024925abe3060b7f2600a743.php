<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>PMS</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="index"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">community</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                      
                                        <button class="btn btn-primary mb-4" data-toggle="modal" data-target="#loginModal">Add Question</button>
             
                        <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Put Question</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="addquestion" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="modelemail">Problem Name</label>
                                                <input type="text" class="form-control" name="problem">
                                            </div>
                                            <div class="form-group">
                                                <label for="modelpass">Problem Details</label>
                                                <textarea type="text" class="form-control" name="details"></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-primary form-control">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                  
                        <div class="row">
                            <div class="col-12">
                                <div class="card card-statistics mail-contant">
                                    <div class="card-body p-0">
                                        <div class="row no-gutters">
                                            
                                            <div class="col-md-12  col-xxl-12 border-md-t">
                                                <div class="mail-content  border-right border-n h-100">
                                                    
                                                    <div class="mail-msg scrollbar scroll_dark">
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($row1->user_id == $row->user_id): ?>
                                                            <div class="mail-msg-item">
                                                                <a href="problem-show/<?php echo e($row->problem_id); ?>/<?php echo e($row->user_id); ?>">
                                                                    <div class="media align-items-center">
                                                                        <div class="mr-3">
                                                                            <div class="bg-img">
                                                                                <img src="assets/img/profile/<?php echo e($row1->profile); ?>" class="img-fluid" alt="user">
                                                                            </div>
                                                                        </div>
                                                                        <div class="w-100">
                                                                            <div class="mail-msg-item-titel justify-content-between">
                                                                                
                                                                                    <p><?php echo e($row1->name); ?></p>
                                                                               
                                                                                <p class="d-none d-xl-block"><?php echo e($row->time); ?> </p>
                                                                            </div>
                                                                            <h5 class="mb-0 my-2"><?php echo e($row->problem_name); ?></h5>
                                                                            <p><?php echo e($row->problem); ?></p>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
            </div>
            <!-- end app-container -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/community.blade.php ENDPATH**/ ?>