;
<h1>Profile</h1>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BVM\Project\PMS\resources\views/profile.blade.php ENDPATH**/ ?>