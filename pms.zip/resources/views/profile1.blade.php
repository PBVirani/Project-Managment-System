
<h1>Profile</h1>
@foreach($user as $u)
    <h3>{{$u->name}}</h3>
@endforeach
