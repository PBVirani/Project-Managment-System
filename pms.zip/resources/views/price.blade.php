@extends('header')
<h1>Price</h1>